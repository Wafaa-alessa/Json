package com.example.jsonapp


import com.google.gson.annotations.SerializedName

class Datum {

    @SerializedName("date")
    var date: String? = null

    @SerializedName("eur")
    var eur: CurrencyDetails? = null

    class CurrencyDetails {

        @SerializedName("inr")
        var inr: String? = null

        @SerializedName("usd")
        var usd: String? = null

        @SerializedName("aud")
        var aud: String? = null

        @SerializedName("sar")
        var sar: String? = null

        @SerializedName("cny")
        var cny: String? = null

        @SerializedName("jpy")
        var jpy: String? = null

        @SerializedName("ada")
        var ada: String? = null

        @SerializedName("all")
        var all: String? = null
    }
}