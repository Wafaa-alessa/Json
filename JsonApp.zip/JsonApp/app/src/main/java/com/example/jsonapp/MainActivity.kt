package com.example.jsonapp


import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private var curencyDetails: Datum? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val userinput = findViewById<View>(R.id.input) as EditText
        val convert = findViewById<View>(R.id.button) as Button
        val spinner = findViewById<View>(R.id.line) as Spinner

        val currencydetails = arrayListOf("inr", "usd", "aud", "sar", "cny", "jpy", "ada", "all")

        var selected: Int = 0

        if (spinner != null) {
            val adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item, currencydetails
            )
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View, position: Int, id: Long
                ) {
                    selected = position
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }
        convert.setOnClickListener {

            var select = userinput.text.toString()
            var curr: Double = select.toDouble()

            getCurrency(onResult = {
                curencyDetails = it

                when (selected) {
                    0 -> disp(calc(curencyDetails?.eur?.inr?.toDouble(), curr));
                    1 -> disp(calc(curencyDetails?.eur?.usd?.toDouble(), curr));
                    2 -> disp(calc(curencyDetails?.eur?.aud?.toDouble(), curr));
                    3 -> disp(calc(curencyDetails?.eur?.sar?.toDouble(), curr));
                    4 -> disp(calc(curencyDetails?.eur?.cny?.toDouble(), curr));
                    5 -> disp(calc(curencyDetails?.eur?.jpy?.toDouble(), curr));
                    6 -> disp(calc(curencyDetails?.eur?.ada?.toDouble(), curr));
                    7 -> disp(calc(curencyDetails?.eur?.all?.toDouble(), curr));
                }
            })
        }

    }

    private fun disp(calc: Double) {

        val responseText = findViewById<View>(R.id.textView3) as TextView

        responseText.text = "result " + calc
    }

    private fun calc(i: Double?, sel: Double): Double {
        var s = 0.0
        if (i != null) {
            s = (i * sel)
        }
        return s
    }

    private fun getCurrency(onResult: (Datum?) -> Unit) {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)

        if (apiInterface != null) {
            apiInterface.getCurrency()?.enqueue(object : Callback<Datum> {
                override fun onResponse(
                    call: Call<Datum>,
                    response: Response<Datum>
                ) {
                    onResult(response.body())

                }

                override fun onFailure(call: Call<Datum>, t: Throwable) {
                    onResult(null)
                    Toast.makeText(applicationContext, "" + t.message, Toast.LENGTH_SHORT).show();
                }

            })
        }
    }
}